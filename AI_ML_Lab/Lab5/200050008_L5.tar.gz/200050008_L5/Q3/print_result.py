import numpy as np

print(np.load('losses.npy'))
print(np.load('weights.npy'))