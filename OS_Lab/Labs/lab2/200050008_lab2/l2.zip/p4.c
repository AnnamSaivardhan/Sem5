#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include<sys/wait.h>
#include<fcntl.h>
#include<stdlib.h>
#include<sys/stat.h>




#include<stdio.h>
#include<unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include<sys/stat.h>
#include <fcntl.h> 
#include <stdlib.h> 

int main(){
    char* f1,*f2;
    size_t size = 50;
    f1 = (char*)malloc(size* sizeof(char));
    f2 = (char*)malloc(size * sizeof(char));
    int f1char = getline(&f1,&size,stdin);
    int f2char = getline(&f2,&size,stdin);
    char c[500];
    f1[f1char-1]='\0';
    f2[f2char-1]='\0';
    int fd = open(f1,O_RDONLY);
    size_t  k = read(fd, c, 500);
    int fd2 = open(f2,O_RDWR | O_CREAT,0777);
    int sz = write(fd2,c,k);
}



// int main(){

    






//     char a[50];
//     char b[50];
//     char *c;
//     scanf("%s",a);
//     scanf("%s",b);
//     int fd1=open(a,O_RDONLY);
//     int fd2=open(b,O_RDWR);
//     //int fd3=open("abc.txt",O_RDWR);
//     // printf("%d\n",fd1);
//     // printf("%d\n",fd2);
//     // printf("%d\n",fd3);
//     read(fd1,c,sizeof(a));
//     printf("%s\n",c);
//     write(fd2,c,sizeof(a));
//     close(fd1);
//     close(fd2);


// }