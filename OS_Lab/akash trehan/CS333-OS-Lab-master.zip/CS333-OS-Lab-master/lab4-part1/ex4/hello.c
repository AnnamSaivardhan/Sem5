#include "types.h"
#include "defs.h"

void
hello(void)
{
  cprintf("Hi! Welcome to the world of xv6!\n");
}